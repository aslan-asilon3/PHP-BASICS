# ☀️🌤⛈❄️ A weather web application using Html, Css, Javascript, Weathermap Api

## Screenshot
<img src="https://github.com/Bhaskar-maity/Javascript-weather-app/blob/main/Screenshot.jpg">

The API provider: http://www.OpenWeatherMap.org

## Live demo
[Javascript Weather App](https://bhaskar-maity.github.io/Javascript-weather-app/)
